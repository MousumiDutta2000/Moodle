<?php

defined('MOODLE_INTERNAL') || die();

#require_once(dirname(__FILE__).'/../locallib.php');
#require_once(dirname(__FILE__).'/../../../lib/sessionlib.php');
#require_once(dirname(__FILE__).'/../../../lib/datalib.php');


class autoattendmod_handler 
{

    public static function get_attendances_handler($userid) 
    {
        return "MORE HELL World!!!";
    }
}
